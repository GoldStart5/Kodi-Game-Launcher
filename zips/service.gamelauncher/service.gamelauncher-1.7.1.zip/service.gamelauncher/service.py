# -*- coding: utf-8 -*-
"""Game Launcher service for Kodi (Windows).

Watches the player. When the file being played is named like the trigger file
(default: Play.avi) it:
  1. stops playback (or waits for the intro to finish, depending on settings),
  2. finds the .lnk in the same folder (prefers "<folder name>.lnk"),
  3. shows the game's fanart full screen while the game loads (artwork comes from
     the Kodi library first, e.g. scraped online art, then the local folder),
  4. launches the shortcut with os.startfile().

The splash closes when another application takes the foreground (the game or
its launcher), when the timeout expires, or when the user presses Back.
"""
import json
import os
import random
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_STOP = 13

IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp")

INTRO_LEAD = 0.35      # pause the intro this many seconds before its end (holds the last frame)
FADE_SECONDS = 0.7     # length of the black fade-in; Kodi runs it, frame by frame
_now = time.monotonic


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)


# --------------------------------------------------------------------------
# Pure helpers (no Kodi UI) - easy to test
# --------------------------------------------------------------------------
def find_lnk(folder):
    """Return the shortcut to launch: '<folder name>.lnk' first, else the first .lnk."""
    try:
        names = sorted(os.listdir(folder))
    except OSError as exc:
        log("Cannot list %s: %s" % (folder, exc), xbmc.LOGERROR)
        return None
    lnks = [n for n in names if n.lower().endswith(".lnk")]
    if not lnks:
        return None
    wanted = os.path.basename(os.path.normpath(folder)).lower() + ".lnk"
    for n in lnks:
        if n.lower() == wanted:
            return os.path.join(folder, n)
    return os.path.join(folder, lnks[0])


def _find_image(folder, bases):
    try:
        names = os.listdir(folder)
    except OSError:
        return ""
    lower = {n.lower(): n for n in names}
    for base in bases:
        for ext in IMAGE_EXTS:
            hit = lower.get(base + ext)
            if hit:
                return os.path.join(folder, hit)
    return ""


def find_fanart(folder):
    name = os.path.basename(os.path.normpath(folder)).lower()
    return _find_image(folder, ("fanart", "background", "backdrop", name + "-fanart"))


def find_logo(folder):
    name = os.path.basename(os.path.normpath(folder)).lower()
    return _find_image(folder, ("clearlogo", "logo", name + "-clearlogo", name + "-logo"))


# --------------------------------------------------------------------------
# Artwork: Kodi library (scraped) and local files
# --------------------------------------------------------------------------
def _rpc(method, params):
    try:
        raw = xbmc.executeJSONRPC(json.dumps(
            {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))
        return json.loads(raw).get("result") or {}
    except Exception as exc:
        log("JSON-RPC %s failed: %s" % (method, exc), xbmc.LOGWARNING)
        return {}


def library_item_playing():
    """Library details of the video item now playing: {id, type, art, playcount} or {}."""
    for p in _rpc_list("Player.GetActivePlayers") or []:
        if p.get("type") == "video":
            item = _rpc("Player.GetItem", {"playerid": p.get("playerid", 1),
                                           "properties": ["art", "playcount"]}).get("item", {})
            return item
    return {}


def playing_item_quick():
    """Info about the video playing now, read from Kodi's info labels.

    Instant (no JSON-RPC), so the start of a launch is never held up by a library
    request. Returns {id, type, playcount, art}; `id` is missing for non-library items.
    """
    gi = xbmc.getInfoLabel
    art = {}
    for key in ("fanart", "clearlogo", "logo"):
        value = gi("Player.Art(%s)" % key)
        if value:
            art[key] = value
    try:
        dbid = int(gi("VideoPlayer.DBID") or 0)
    except ValueError:
        dbid = 0
    if not dbid or not xbmc.getCondVisibility("VideoPlayer.Content(movies)"):
        return {"art": art}
    try:
        playcount = int(gi("VideoPlayer.PlayCount") or 0)
    except ValueError:
        playcount = 0
    return {"id": dbid, "type": "movie", "playcount": playcount, "art": art}


def _rpc_list(method):
    try:
        raw = xbmc.executeJSONRPC(json.dumps(
            {"jsonrpc": "2.0", "id": 1, "method": method, "params": {}}))
        return json.loads(raw).get("result")
    except Exception as exc:
        log("JSON-RPC %s failed: %s" % (method, exc), xbmc.LOGWARNING)
        return None


def _same_folder(a, b):
    return os.path.normcase(os.path.normpath(a)) == os.path.normcase(os.path.normpath(b))


def library_movie_for_folder(folder):
    """Find the game in the video library by its folder. Returns the movie dict or {}."""
    name = os.path.basename(os.path.normpath(folder))
    if not name:
        return {}
    res = _rpc("VideoLibrary.GetMovies", {
        "filter": {"field": "path", "operator": "contains", "value": name},
        "properties": ["art", "file", "playcount"]})
    for m in res.get("movies", []):
        f = m.get("file") or ""
        if f and _same_folder(os.path.dirname(f), folder):
            return m
    return {}


def mark_played(movie_id, original_playcount):
    """Make the game sort as 'last played' without leaving it marked as watched.

    Kodi marks Play.avi watched if the intro plays to the end, so first put the play
    count back, then write the last-played time (in that order, so the date is not
    cleared by the play-count change).
    """
    if movie_id is None:
        return
    d = _rpc("VideoLibrary.GetMovieDetails",
             {"movieid": movie_id, "properties": ["playcount"]}).get("moviedetails", {})
    if original_playcount is not None and (d.get("playcount") or 0) > original_playcount:
        _rpc("VideoLibrary.SetMovieDetails",
             {"movieid": movie_id, "playcount": original_playcount})
    _rpc("VideoLibrary.SetMovieDetails",
         {"movieid": movie_id, "lastplayed": time.strftime("%Y-%m-%d %H:%M:%S")})
    log("Updated last played for library item %s" % movie_id)


def _art_pair(art):
    art = art or {}
    logo = (art.get("clearlogo") or art.get("logo")
            or art.get("set.clearlogo") or art.get("tvshow.clearlogo") or "")
    return art.get("fanart") or "", logo


def resolve_art(folder, lib_art, source):
    """Pick (fanart, logo). source: 0 library first, 1 local first, 2 local only."""
    local = (find_fanart(folder), find_logo(folder))
    lib = _art_pair(lib_art) if source != 2 else ("", "")
    first, second = (local, lib) if source in (1, 2) else (lib, local)
    fanart = first[0] or second[0]
    logo = first[1] or second[1]
    return fanart, logo


def foreground_is_kodi():
    """True if Kodi owns the foreground window (or we cannot tell)."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return True
        pid = ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return pid.value == os.getpid()
    except Exception:  # not Windows / ctypes missing -> rely on timeout
        return True


def _enum_windows(match):
    """Handles of visible top-level windows whose (hwnd, pid, owner) satisfy match()."""
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def enum_cb(hwnd, _lparam):
        pid = wintypes.DWORD(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if user32.IsWindowVisible(hwnd) and match(hwnd, pid.value, user32.GetWindow(hwnd, 4)):
            found.append(hwnd)     # GW_OWNER = 4
        return True

    user32.EnumWindows(enum_cb, 0)
    return found


def _kodi_windows():
    me = os.getpid()
    return _enum_windows(lambda hwnd, pid, owner: pid == me and not owner)


def minimize_kodi_window():
    """Minimise Kodi's own main window (Windows). Returns True if a window was minimised."""
    try:
        import ctypes
        found = _kodi_windows()
        for hwnd in found:
            ctypes.windll.user32.ShowWindow(hwnd, 6)      # SW_MINIMIZE
        return bool(found)
    except Exception as exc:
        log("Minimise failed: %s" % exc, xbmc.LOGWARNING)
        return False


def restore_kodi_window():
    """Bring Kodi's window back and give it focus (Windows)."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        # A synthetic Alt key press lets SetForegroundWindow through Windows' focus lock.
        user32.keybd_event(0x12, 0, 0, 0)
        user32.keybd_event(0x12, 0, 2, 0)
        for hwnd in _kodi_windows():
            user32.ShowWindow(hwnd, 9)                    # SW_RESTORE
            user32.SetForegroundWindow(hwnd)
        return True
    except Exception as exc:
        log("Restore failed: %s" % exc, xbmc.LOGWARNING)
        return False


_SHELL_CLASSES = ("Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd")


def foreground_app():
    """(pid, is_shell) of the foreground window. pid is 0 when there is none."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return 0, True
        pid = ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        buf = ctypes.create_unicode_buffer(64)
        user32.GetClassNameW(hwnd, buf, 64)
        return pid.value, buf.value in _SHELL_CLASSES
    except Exception:
        return 0, False


def app_has_windows(pid):
    """True while the process still has a visible top-level window."""
    try:
        return bool(_enum_windows(lambda hwnd, p, owner: p == pid and not owner))
    except Exception:
        return True    # cannot tell -> assume it is still running

# --------------------------------------------------------------------------
# Splash window
# --------------------------------------------------------------------------
def black_texture():
    """Path of a solid black image (an image control with no texture draws nothing)."""
    path = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")),
                        "resources", "media", "black.png")
    if not os.path.exists(path):
        log("black.png missing - splash will not have a solid background", xbmc.LOGWARNING)
        return ""
    return path


class Splash(xbmcgui.WindowDialog):
    def __init__(self, fanart, logo, title, animate=True, black_delay_ms=3000, zoom_mode=0):
        super(Splash, self).__init__()
        self.closed_by_user = False
        w, h = self.getWidth(), self.getHeight()

        # Whole-window fade in / fade out (applies to every control)
        black = black_texture()
        bg = xbmcgui.ControlImage(0, 0, w, h, black)
        self.addControl(bg)

        art = None
        if fanart:
            # aspectRatio 1 = scale to fill, cropping the overflow
            art = xbmcgui.ControlImage(0, 0, w, h, fanart, aspectRatio=1)
            self.addControl(art)

        mark = None
        if logo:
            lw, lh = int(w * 0.4), int(h * 0.25)
            mark = xbmcgui.ControlImage(
                (w - lw) // 2, int(h * 0.50) - lh // 2, lw, lh, logo, aspectRatio=2)
        else:
            mark = xbmcgui.ControlLabel(
                0, int(h * 0.42), w, 80, title, font="font30_title",
                textColor="0xFFFFFFFF", alignment=6)
        self.addControl(mark)

        status = xbmcgui.ControlLabel(
            0, int(h * 0.86), w, 40, ADDON.getLocalizedString(30100),
            font="font13", textColor="0xCCFFFFFF", alignment=6)
        self.addControl(status)

        fade_in = "effect=fade start=0 end=100 time=%d tween=sine easing=out"
        fade_out = "effect=fade start=100 end=0 time=500 tween=sine easing=in"

        art_anims, mark_anims, status_anims = [], [], []
        if animate:
            bg.setAnimations([("WindowOpen", fade_in % 600), ("WindowClose", fade_out)])
            # zoom_mode: 0 = zoom in then out, 1 = zoom out then in, 2 = random
            if zoom_mode == 2:
                zoom_mode = random.choice((0, 1))
            # Never go below 100% (that would show black edges around the art).
            # A pulse runs start -> end -> start, so swapping them flips the direction.
            # (Kodi's pulse plays this the opposite way round on screen, so the values are
            # deliberately swapped: mode 0 = in then out, mode 1 = out then in.)
            z_start, z_end = (100, 112) if zoom_mode == 1 else (112, 100)
            art_anims += [
                ("WindowOpen", fade_in % 900),
                ("WindowClose", fade_out),
                # slow "Ken Burns" zoom that eases back the other way, repeating
                ("Conditional",
                 "effect=zoom start=%d end=%d center=auto time=14000 "
                 "tween=sine easing=inout pulse=true condition=true" % (z_start, z_end)),
            ]
            # logo / title appears a moment after the fanart, with a small rise
            mark_anims += [
                ("WindowOpen", "effect=fade start=0 end=100 delay=500 time=900 tween=sine easing=out"),
                ("WindowOpen", "effect=slide start=0,20 end=0,0 delay=500 time=900 tween=cubic easing=out"),
                ("WindowClose", fade_out),
            ]
            # status text gently pulses so the screen feels alive while waiting
            status_anims += [
                ("WindowOpen", "effect=fade start=0 end=100 delay=900 time=600"),
                ("Conditional",
                 "effect=fade start=100 end=45 time=1400 tween=sine easing=inout "
                 "pulse=true condition=true"),
                ("WindowClose", fade_out),
            ]

        for ctl, anims in ((art, art_anims), (mark, mark_anims), (status, status_anims)):
            if ctl is not None and anims:
                ctl.setAnimations(anims)

        # Black overlay on top of everything. Kodi's animation engine keeps it fully
        # transparent for `black_delay_ms`, then fades it in smoothly (every rendered
        # frame) and leaves it black. The splash stays underneath until the window closes.
        overlay = xbmcgui.ControlImage(0, 0, w, h, black)
        self.addControl(overlay)
        overlay.setAnimations([(
            "WindowOpen",
            "effect=fade start=0 end=100 delay=%d time=%d tween=sine easing=inout"
            % (black_delay_ms, int(FADE_SECONDS * 1000)))])

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_STOP):
            self.closed_by_user = True
            self.close()


# --------------------------------------------------------------------------
# Player + service loop
# --------------------------------------------------------------------------
class FadeCover(xbmcgui.WindowDialog):
    """Black layer that fades in over whatever is on screen (used over the paused last
    frame of the intro video). Kodi runs the fade, so it is drawn every frame."""

    def __init__(self):
        super(FadeCover, self).__init__()
        self.closed_by_user = False
        w, h = self.getWidth(), self.getHeight()
        cover = xbmcgui.ControlImage(0, 0, w, h, black_texture())
        self.addControl(cover)
        cover.setAnimations([(
            "WindowOpen",
            "effect=fade start=0 end=100 time=%d tween=sine easing=inout"
            % int(FADE_SECONDS * 1000))])

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_STOP):
            self.closed_by_user = True
            self.close()


class GamePlayer(xbmc.Player):
    def __init__(self):
        super(GamePlayer, self).__init__()
        self.pending = None       # path of Play.avi that should trigger a launch
        self.pending_intro = False  # True when the launch comes at the end of the intro video
        self._armed_for = None    # trigger file seen playing (for "after intro" mode)
        self.item = {}            # library item that started the launch
        self._triggered_at = None  # when the trigger file started playing (for timing logs)
        self.deferred_marks = []  # (due_time, movie_id, original_playcount): written by service_tick

    @staticmethod
    def _settings():
        a = xbmcaddon.Addon()
        return {
            "trigger": (a.getSetting("trigger_name") or "play.avi").strip().lower(),
            "mode": int(a.getSetting("launch_mode") or 0),
            "splash": a.getSetting("show_splash") != "false",
            "timeout": int(a.getSetting("splash_timeout") or 30),
            "animate": a.getSetting("animate_splash") != "false",
            "zoom_mode": min(2, max(0, int(a.getSetting("zoom_mode") or 2))),
            "art_source": int(a.getSetting("art_source") or 0),
            "track": a.getSetting("track_lastplayed") != "false",
            "splash_time": min(7, max(1, int(a.getSetting("splash_time") or 3))),
        }

    def _current_trigger_path(self):
        cfg = self._settings()
        try:
            path = self.getPlayingFile()
        except RuntimeError:
            return None
        if not path:
            return None
        local = xbmcvfs.translatePath(path) if path.startswith("special://") else path
        if os.path.basename(local).lower() != cfg["trigger"]:
            return None
        return local

    def _on_started(self):
        path = self._current_trigger_path()
        if not path:
            self._armed_for = None
            return
        cfg = self._settings()
        log("Trigger file playing: %s" % path)
        self._triggered_at = _now()
        self.item = playing_item_quick()   # no JSON-RPC here: stop the video as fast as possible
        if cfg["mode"] == 0:      # launch immediately
            self.pending_intro = False
            self.pending = path
        else:                     # wait for the intro to end
            self._armed_for = path

    def onAVStarted(self):
        self._on_started()

    def onPlayBackEnded(self):
        # Fallback: the intro ended before poll_intro_end() could hold its last frame.
        if self._armed_for:
            self.pending_intro = True
            self.pending = self._armed_for
            self._armed_for = None

    def poll_intro_end(self):
        """'After the intro' mode: hold the intro's last frame by pausing just before the end."""
        if not self._armed_for or self.pending:
            return
        try:
            if not self.isPlaying():
                return
            total, cur = self.getTotalTime(), self.getTime()
        except RuntimeError:
            return
        if total <= 0:
            return
        if total - cur <= min(INTRO_LEAD, total * 0.25):
            self.pause()
            log("Intro paused on its last frame (%.2f of %.2f s)" % (cur, total))
            self.pending_intro = True
            self.pending = self._armed_for
            self._armed_for = None

    def onPlayBackStopped(self):
        self._armed_for = None


def launch(player, path, from_intro=False):
    """Launch the game for `path`.

    from_intro=False: stop the video, show the fanart splash, then fade to black and launch.
    from_intro=True : the intro is paused on its last frame; fade black over it (no splash),
                      launch, then stop the video once the game has the foreground.

    Nothing slow runs before the splash is on screen: library requests are either avoided
    (info labels) or done while the splash is already showing, and the last-played update
    is written only after the game is in front.
    """
    cfg = player._settings()
    folder = os.path.dirname(path)
    triggered_at = player._triggered_at

    def release_video():
        if from_intro and player.isPlaying():
            player.stop()

    item = dict(player.item or {})
    want_art = cfg["splash"] and cfg["art_source"] != 2 and not from_intro
    # Slow path, only when Kodi's info labels told us nothing about the item: ask the
    # library now, because the item is gone once the video has been stopped.
    if (want_art or cfg["track"]) and item.get("id") is None and player.isPlaying():
        rpc_item = library_item_playing()
        if rpc_item.get("type") == "movie" and rpc_item.get("id") is not None:
            item = rpc_item

    if player.isPlaying() and not from_intro:
        player.stop()
    stopped_at = _now()

    lnk = find_lnk(folder)
    if not lnk:
        log("No .lnk found in %s" % folder, xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Game Launcher", ADDON.getLocalizedString(30101),
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        release_video()
        return

    title = os.path.splitext(os.path.basename(lnk))[0]
    movie_id = item.get("id")
    original_playcount = item.get("playcount") if movie_id is not None else None

    splash = None
    shown_at = None
    if from_intro:
        splash = FadeCover()
        splash.show()
        shown_at = _now()
    elif cfg["splash"]:
        fanart, logo = resolve_art(folder, item.get("art") or {}, cfg["art_source"])
        log("Library art keys: %s" % (", ".join(sorted(item.get("art") or {})) or "-"))
        log("Splash art: fanart=%s logo=%s" % (fanart or "-", logo or "-"))
        if not logo:
            log("No clearlogo found (library or local) - showing the game title instead")
        splash = Splash(fanart, logo, title, cfg["animate"], cfg["splash_time"] * 1000,
                        cfg["zoom_mode"])
        splash.show()
        shown_at = _now()
        if triggered_at is not None:
            log("Launch timing: video stopped %.2f s after it started, splash shown %.2f s later"
                % (stopped_at - triggered_at, shown_at - stopped_at))

    monitor = xbmc.Monitor()

    def find_movie_late():
        """Look the game up by folder (only when we still have no library id)."""
        m = library_movie_for_folder(folder)
        if m:
            return m.get("movieid"), m.get("playcount") or 0
        log("Game is not in the Kodi library - last played not updated")
        return None, None

    if cfg["track"] and movie_id is None and splash:
        movie_id, original_playcount = find_movie_late()   # the splash is already showing

    # Splash time, then the black layer fades in over the splash (Kodi animates it),
    # then the game starts from the black screen. Back skips the rest of the wait.
    if splash:
        hold = 0.0 if from_intro else cfg["splash_time"]
        launch_at = shown_at + hold + FADE_SECONDS + 0.1
        while (_now() < launch_at and not monitor.abortRequested()
               and not splash.closed_by_user):
            if player.pending:
                # Play.avi was started again while this launch is already under way:
                # stop that stray video at once instead of letting it play.
                player.pending, player.pending_intro = None, False
                if player.isPlaying():
                    player.stop()
                log("Play pressed again during launch - ignored")
            monitor.waitForAbort(0.05)
        if monitor.abortRequested():
            release_video()
            splash.close()
            return

    log("Launching %s" % lnk)
    try:
        os.startfile(lnk)  # Windows only
    except Exception as exc:
        log("Launch failed: %s" % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Game Launcher", str(exc),
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        release_video()
        if splash:
            splash.close()
        return
    launched_at = _now()

    if splash:
        waited = 0.0
        grace = 2.0    # give the new app time to take focus before we check
        step = 0.25
        next_check = 0.0
        while (waited < cfg["timeout"] and not monitor.abortRequested()
               and not splash.closed_by_user and not player.pending):
            monitor.waitForAbort(0.05)     # short slices: a new Play.avi must be noticed fast
            waited += 0.05
            if waited >= next_check:
                next_check += step
                if waited > grace and not foreground_is_kodi():
                    log("Another app has the foreground - closing splash")
                    break
        release_video()   # intro mode: stop the (paused) video only now, behind the black layer
        splash.close()
        if cfg["animate"] and not from_intro:
            end = _now() + 0.6   # let the close animation finish, unless a new launch is waiting
            while _now() < end and not monitor.abortRequested() and not player.pending:
                monitor.waitForAbort(0.05)
        del splash
    elif cfg["track"] and movie_id is None:
        movie_id, original_playcount = find_movie_late()

    # Last: queue the library update. It must NOT be waited for here: this function blocks the
    # service loop, and a new Play.avi started meanwhile would keep playing until we return.
    # service_tick() writes it once Kodi's own save after the video stop is long finished.
    if cfg["track"] and movie_id is not None:
        player.deferred_marks = [m for m in player.deferred_marks if m[1] != movie_id]
        player.deferred_marks.append((launched_at + 2.5, movie_id, original_playcount))


def service_tick(player):
    if player.pending:
        path, from_intro = player.pending, player.pending_intro
        player.pending, player.pending_intro = None, False
        try:
            launch(player, path, from_intro)
        except Exception:  # never let the service die
            log("Unexpected error:\n%s" % traceback.format_exc(), xbmc.LOGERROR)
    player.poll_intro_end()
    # Library writes run only when no launch is waiting, so they never delay stopping a video.
    if player.deferred_marks and not player.pending:
        due = [m for m in player.deferred_marks if _now() >= m[0]]
        for m in due:
            player.deferred_marks.remove(m)
            try:
                mark_played(m[1], m[2])
            except Exception:
                log("Last played update failed:\n%s" % traceback.format_exc(), xbmc.LOGERROR)


class FocusMinimizer(object):
    """Minimise Kodi once it has been out of focus for `delay` seconds (to save GPU),
    and bring it back when the app that had the focus (the game) closes.

    Restore rule: the app in the foreground when Kodi was minimised is tracked. When all
    its windows are gone, Kodi is restored if focus fell to the desktop/taskbar (or nothing).
    If focus lands on another normal app instead (a launcher handing over to the game, or
    the game closing into a browser), that app is tracked from then on, so Kodi never
    jumps in front of something you are using. Restoring it yourself from the taskbar
    always works.
    """

    CHECK_EVERY = 0.5
    GONE_GRACE = 1.5      # seconds the tracked app must be gone before Kodi is restored

    def __init__(self):
        self._reset()
        self._next_check = 0.0

    def _reset(self):
        self.lost_at = None
        self.done = False         # already minimised for this focus loss
        self.tracked_pid = None   # app to wait for before restoring Kodi
        self.gone_since = None

    def tick(self):
        now = _now()
        if now < self._next_check:
            return
        self._next_check = now + self.CHECK_EVERY
        a = xbmcaddon.Addon()
        if a.getSetting("minimize_unfocused") != "true":
            self._reset()
            return
        if foreground_is_kodi():
            self._reset()
            return
        if self.done:
            self._follow_game(now, a.getSetting("restore_on_exit") != "false")
            return
        if self.lost_at is None:
            self.lost_at = now
        delay = min(60, max(1, int(a.getSetting("minimize_delay") or 5)))
        if now - self.lost_at >= delay:
            self.done = True
            pid, is_shell = foreground_app()
            self.tracked_pid = None if (is_shell or not pid) else pid
            if minimize_kodi_window():
                log("Kodi out of focus for %d s - minimised (tracking pid %s)"
                    % (delay, self.tracked_pid))

    def _follow_game(self, now, restore):
        if not restore or not self.tracked_pid:
            return
        if app_has_windows(self.tracked_pid):
            self.gone_since = None
            return
        pid, is_shell = foreground_app()
        if not is_shell and pid and pid != self.tracked_pid:
            self.tracked_pid, self.gone_since = pid, None     # handed over to another app
            return
        if self.gone_since is None:
            self.gone_since = now
        if now - self.gone_since >= self.GONE_GRACE:
            log("App that had the focus has closed - restoring Kodi")
            restore_kodi_window()
            self._reset()


def main():
    monitor = xbmc.Monitor()
    player = GamePlayer()
    minimizer = FocusMinimizer()
    log("Service started")
    while not monitor.abortRequested():
        service_tick(player)
        minimizer.tick()
        # check often: the video must be stopped the moment the trigger file starts
        if monitor.waitForAbort(0.05):
            break
    log("Service stopped")


if __name__ == "__main__":
    main()
